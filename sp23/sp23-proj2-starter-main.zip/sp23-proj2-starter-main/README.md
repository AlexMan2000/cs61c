# 61C Spring 2023 Project 2: CS61Classify

Spec: [https://cs61c.org/sp23/projects/proj2/](https://cs61c.org/sp23/projects/proj2/)
