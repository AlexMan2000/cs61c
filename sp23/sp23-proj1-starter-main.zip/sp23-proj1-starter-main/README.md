# 61C Spring 2023 Project 1: snek

Spec: [https://cs61c.org/sp23/projects/proj1/](https://cs61c.org/sp23/projects/proj1/)
